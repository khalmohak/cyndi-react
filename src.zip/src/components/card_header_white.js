import React, { Component } from 'react';

// import './App.css';
 
class CardHeader extends Component {
  render() {
    return (
      
    <img
      src='/static/card_bg.svg'
      className="logo"
      alt="cardHeader"
      width='100%'
      height='155'
    />
    )
  }
}

export default CardHeader 