import React, { Component } from 'react';

// import './App.css';
 
class CardHeader extends Component {
  render() {
    return (
      
    
    )
  }
}

export default CardHeader 