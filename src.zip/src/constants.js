const apiEndPoint = "http://cyndi-backend.ap-south-1.elasticbeanstalk.com:4000";
export {apiEndPoint};

